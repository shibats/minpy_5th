def test_func(number):
    for count in range(number):
        print(count*10)

a = 4
b = "パイソン"
