from test_package2.sub_module import test_func, a, b
print("これは__init__.pyから出力された文字列です。")
